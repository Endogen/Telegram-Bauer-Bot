#!/bin/bash

python3.7 -m bauer -lvl 20