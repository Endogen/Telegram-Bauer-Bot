import os
import sqlite3
import inspect
import logging
import threading
import bauer.emoji as emo
import bauer.constants as c

from telegram import ChatAction
from bauer.config import ConfigManager as Cfg


class BauerPluginInterface:

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        pass

    # command string that triggers the plugin
    def get_handle(self):
        method = inspect.currentframe().f_code.co_name
        raise NotImplementedError(f"Interface method '{method}' not implemented")

    # Logic that gets executed if command is triggered
    def get_action(self, bot, update, args):
        method = inspect.currentframe().f_code.co_name
        raise NotImplementedError(f"Interface method '{method}' not implemented")

    # TODO: Read .md file from plugins dir and show content
    # How to use the command
    def get_usage(self):
        return None

    # Short description what the command does
    def get_description(self):
        return None

    # Category for command
    def get_category(self):
        return None


class BauerPlugin(BauerPluginInterface):

    def __init__(self, telegram):
        super().__init__()

        self.telegram = telegram  # TODO: Make private?

        name = type(self).__name__.lower()
        self._db_path = os.path.join(c.DAT_DIR, f"{name}.db")
        data_dir = os.path.dirname(self._db_path)
        os.makedirs(data_dir, exist_ok=True)

    # TODO: Make private and use automatically in 'execute_sql()'?
    def get_sql(self, filename):
        """ Return SQL statement from file """
        cls = inspect.stack()[1][0].f_locals["self"].__class__  # TODO: Remove?
        cls_name = cls.__name__.lower()
        filename = f"{filename}.sql"

        # TODO: Try block
        with open(os.path.join(c.SQL_DIR, cls_name, filename)) as f:
            return f.read()

    def execute_sql(self, sql, *args):
        """ Execute raw SQL statement on database """
        res = {"success": None, "data": None}
        con = sqlite3.connect(self._db_path)
        cur = con.cursor()

        try:
            cur.execute(sql, args)
            con.commit()
            res["data"] = cur.fetchall()
            res["success"] = True
        except Exception as e:
            logging.error(e)
            res["data"] = str(e)
            res["success"] = False

        con.close()
        return res

    def table_exists(self, table_name):
        """ Return TRUE if table exists, otherwise FALSE """
        con = sqlite3.connect(self._db_path)
        cur = con.cursor()
        exists = False

        try:
            # TODO: Do not use 'get_sql()' here
            statement = self.get_sql("table_exists")
            if cur.execute(statement, [table_name]).fetchone():
                exists = True
        except Exception as e:
            logging.error(e)

        con.close()
        return exists

    @staticmethod
    def threaded(fn):
        def wrapper(*args, **kwargs):
            thread = threading.Thread(target=fn, args=args, kwargs=kwargs)
            thread.start()
            return thread

        return wrapper

    @classmethod
    def send_typing(cls, func):
        def _send_typing_action(self, bot, update, **kwargs):
            if update.message:
                user_id = update.message.chat_id
            elif update.callback_query:
                user_id = update.callback_query.message.chat_id
            else:
                return func(self, bot, update, **kwargs)

            try:
                bot.send_chat_action(
                    chat_id=user_id,
                    action=ChatAction.TYPING)
            except Exception as e:
                logging.error(f"{e} - {update}")

            return func(self, bot, update, **kwargs)
        return _send_typing_action

    @classmethod
    def only_owner(cls, func):
        def _only_owner(self, bot, update, **kwargs):
            if update.effective_user.id in Cfg.get("admin_id"):
                return func(self, bot, update, **kwargs)
        return _only_owner

    # TODO: Probably not needed anymore
    @classmethod
    def save_user(cls, func):
        def _save_user(self, bot, update, **kwargs):
            if Cfg.get("database", "use_db"):
                self.tgb.db.save_user(update.effective_user)
            return func(self, bot, update, **kwargs)
        return _save_user

    # TODO: Do i still need this?
    # Handle exceptions (write to log, reply to Telegram message)
    def handle_error(self, error, update, send_error=True):
        cls_name = f"Class: {type(self).__name__}"
        logging.error(f"{repr(error)} - {error} - {cls_name} - {update}")

        if send_error and update and update.message:
            msg = f"{emo.ERROR} {error}"
            update.message.reply_text(msg)

    # Build button-menu for Telegram
    def build_menu(cls, buttons, n_cols=1, header_buttons=None, footer_buttons=None):
        menu = [buttons[i:i + n_cols] for i in range(0, len(buttons), n_cols)]

        if header_buttons:
            menu.insert(0, header_buttons)
        if footer_buttons:
            menu.append(footer_buttons)

        return menu


# Categories for commands
class Category:

    AUTOGAME = "Autogame"
    BISMUTH = "Bismuth"
    DRAGGINATOR = "Dragginator"
    HYPERNODES = "Hypernodes"
    BOT = "Bot"

    @classmethod
    def get_categories(cls):
        categories = list()

        for k, v in vars(cls).items():
            if k.isupper() and isinstance(v, str):
                categories.append({k: v})

        return categories
