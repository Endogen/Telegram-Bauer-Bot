✨ *Bismuth Bauer Bot* ✨

Welcome to Bismuth! I'm Bauer, your friendly Bismuth bot, and if you want to tip someone or if you want to let it rain BIS coins for the Bismuth Telegram community then i will help you out doing that.

Click on /help to see all available commands with a short description or on /about to get more info about me.

If you need more info on how to use the commands, just execute one of them and i will let you know about the arguments that you need to provide.

Cheers 🍻👋