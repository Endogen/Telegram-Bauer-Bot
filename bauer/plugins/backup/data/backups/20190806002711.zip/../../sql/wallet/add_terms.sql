INSERT INTO terms (username, terms_accepted)
VALUES (?, ?)