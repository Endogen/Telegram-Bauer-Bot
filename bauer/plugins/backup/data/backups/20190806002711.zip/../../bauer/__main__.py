from bauer.start import Bauer

Bauer().start()
