INSERT INTO tip (from_username, to_username, amount)
VALUES (?, ?, ?)