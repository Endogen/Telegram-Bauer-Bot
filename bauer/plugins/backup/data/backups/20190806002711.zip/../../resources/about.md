✨ *Bismuth Bauer Bot* ✨
Please visit the [website](https://bismuth.cz) to get detailed information about Bismuth.  

🔹 *Development*
This bot ist open source and the source code can be found over at [GitHub](https://github.com/Endogen/Bauer-Telegram-Bot). He's written in Python and was developed by @endogen for the Bismuth community.

🔹 *Feedback* 
Do you have suggestions for additional commands or want to let us know about bugs you encountered? If so, let us know by using the /feedback command or open an issue on GitHub.